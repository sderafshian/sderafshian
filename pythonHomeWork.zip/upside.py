list1 = ['a', 'b', 'c', 'd', 'e']
print(list1[::-1])
